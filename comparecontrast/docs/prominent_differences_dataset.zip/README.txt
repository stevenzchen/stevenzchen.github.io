------------------------------------------------------------------------------

Dataset for Compare and Contrast: Learning Prominent Visual Differences

For details on annotations collected and preprocessing, please download the paper at
stevenzc.com/comparecontrast.

------------------------------------------------------------------------------

UT-Zap50K Shoes:

The subset of UT-Zap50K images with prominent difference annotations is included in the zap50ksample/ folder.

Matlab files containing UT-Zap50K relative attribute and prominent difference annotations are in the zap/ folder and are described below.
Note: all files and annotations are one-indexed.

zap/zapAttributes: 1 by 10 cell of attribute names.

zap/zapImages: 2000 by 1 cell of image filenames, with each image denoted in other files by index in zapImages.
               For instance, imagelist{5} is the image filename corresponding to index 5.

zap/zapRelativeIndices: 1600 by 2 double of image pairs corresponding to relative attribute annotations.
                        Images are denoted by index.

zap/zapRelative: 1600 by 10 double of attribute labels, rows corresponding to zapRelativeIndices. Label for each attribute
                 is 1 (image1 is MORE attr than image2), 0 (image1 is EQUAL attr than image2), or -1 (image1 is LESS attr than image2).

zap/zapProminentIndices: 4990 by 2 double of image pairs corresponding to prominent difference annotations.
                         Images are denoted by index.

zap/zapProminent: 4990 by 10 double of top chosen prominent difference attributes for each pair. 
                  For instance, top 3 prominent differences for pair 5 would be (5, 1:3).
                  Only attributes chosen at least once are indicated. Zero padding follows after annotated attributes.

The full UT-Zap50K dataset is available at http://vision.cs.utexas.edu/projects/finegrained/utzap50k/.
Note: the attributes used in this work are different from the attributes from the original dataset.

------------------------------------------------------------------------------

LFW10 Faces:

First, download the LFW10 dataset at http://cvit.iiit.ac.in/research/projects/cvit-projects/relative-parts-distinctive-parts-for-learning-relative-attributes.
LFW10 contains images and relative attribute labels.

Matlab files containing LFW10 prominent difference annotations are in the lfw/ folder and are described below.
Note: all files and annotations are one-indexed.

lfw/lfwAttributes: 1 by 10 cell of attribute names.

lfw/lfwProminentIndices: 4990 by 2 double of image pairs corresponding to prominent difference annotations.
                         Images are denoted by index.

lfw/lfwProminent: 4990 by 10 double of top chosen prominent difference attributes for each pair. 
                  For instance, top 3 prominent differences for pair 5 would be (5, 1:3).
                  Only attributes chosen at least once are indicated. Zero padding follows after annotated attributes.

------------------------------------------------------------------------------

If you use this dataset, please cite our work and the following image datasets:

S. Chen and K. Grauman. "Compare and Contrast: Learning Prominent Visual Differences". In CVPR, 2018.

UT-Zap50K Dataset:

A. Yu and K. Grauman. "Fine-Grained Visual Comparisons with Local Learning". In CVPR, 2014.
A. Yu and K. Grauman. "Semantic Jitter: Dense Supervision for Visual Comparisons via Synthetic Images". In ICCV, 2017.

LFW10 Dataset:

R. Sandeep and Y. Verma and C. Jawahar. "Relative Parts: Distinctive Parts for Learning Relative Attributes". In CVPR, 2014.

------------------------------------------------------------------------------

Please contact Steven Chen (http://www.stevenzc.com) with any questions or comments.